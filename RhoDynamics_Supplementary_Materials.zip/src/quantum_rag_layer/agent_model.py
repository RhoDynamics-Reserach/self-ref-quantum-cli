import random
import numpy as np
from .math_engine import calculate_zeta, calculate_fitness, calculate_chi_square, CHI_SQUARE_REF, ZETA_REF, evolve_parameters
from .memory import MemoryBuffer, update_stability_dynamically

class BaseQuantumAgent:
    """
    Lightweight, standalone Agent Model.
    Designed for easy injection into existing chatbot frameworks.
    
    Contains both the semantic state (knowledge_vector) 
    and the cognitive stability metrics (Zeta, Chi^2).
    """
    def __init__(self, name: str, knowledge_vector: np.ndarray = None, measurement_executor=None, seed: int = None):
        self.name = name
        self.executor = measurement_executor
        self.seed = seed
        
        # Initialize RNGs for reproducibility
        if seed is not None:
            random.seed(seed)
            self.rng = np.random.default_rng(seed)
        else:
            self.rng = np.random.default_rng()
        
        # 1. Cognitive Parameters (Seeded if available)
        self.gamma = random.uniform(0.5, 1.5) if seed is None else self.rng.uniform(0.5, 1.5)
        self.gamma_decoherence = random.uniform(0.1, 0.5) if seed is None else self.rng.uniform(0.1, 0.5)
        self.tau_m = 2.0 # Memory kernel decay
        self.theta = random.uniform(0, 3.14) if seed is None else self.rng.uniform(0, 3.14)
        self.memory_size = 100 
        
        # 2. Semantic State (Base Knowledge)
        if knowledge_vector is not None:
            self.knowledge_vector = knowledge_vector
        else:
            # Deterministic initialization baseline
            self.knowledge_vector = np.ones(16) / np.sqrt(16)
            
        # 3. Dynamic Modules
        self.memory = MemoryBuffer(self.tau_m)
        self.history = [] # Track (chi, zeta, fitness) per interaction
        
        # 4. Success Metrics (Calculated from initial state)
        self.chi_square = CHI_SQUARE_REF 
        self.zeta = calculate_zeta(self.gamma, self.gamma_decoherence, self.tau_m)
        self.fitness = calculate_fitness(self.chi_square, self.zeta, self.memory_size)
        
    def evaluate_state(self, current_state_probs: np.ndarray):
        """
        Updates the agent's internal success metrics based on current task performance.
        Now supports Real QPU execution if an executor is provided.
        """
        shots = 1024 # Standard benchmark
        
        if self.executor and hasattr(self.executor, 'run_measurement'):
            outcomes = self.executor.run_measurement(current_state_probs, shots)
        elif callable(self.executor):
            outcomes = self.executor(current_state_probs, shots)
        else:
            # Seeded multinomial sampling
            if self.seed is not None:
                outcomes = self.rng.multinomial(shots, current_state_probs)
            else:
                outcomes = np.random.multinomial(shots, current_state_probs)
            
        self.chi_square = calculate_chi_square(outcomes, shots)
        
        # B. Memory Kernel (Update Zeta/Stability)
        zeta_base = calculate_zeta(self.gamma, self.gamma_decoherence, self.tau_m)
        self.memory.add_state(current_state_probs)
        mem_effect = self.memory.get_memory_effect(current_state_probs)
        self.zeta = update_stability_dynamically(zeta_base, mem_effect)
        
        # C. Total Fitness
        self.fitness = calculate_fitness(self.chi_square, self.zeta, self.memory_size)
        
        # Record history
        self.history.append({
            "chi": self.chi_square,
            "zeta": self.zeta,
            "fitness": self.fitness
        })
        
        return self.fitness

    def evolve(self, learning_rate: float = 0.05):
        """
        Triggers parametric evolution based on the latest interaction results.
        Enables non-linear reinforcement of stable knowledge paths.
        """
        if not self.history: return
        
        current_fit = self.fitness
        self.theta, self.gamma = evolve_parameters(
            self.theta, 
            self.gamma, 
            current_fit, 
            learning_rate
        )
        
        return self.theta, self.gamma
